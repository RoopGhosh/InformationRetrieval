package required;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class TryClass {

	public static void main(String[] args) {/*
		ArrayList<String> haha = new ArrayList<>();
		haha.add("hello");
		haha.add("world");
		haha.add("new");
		haha.add("world");
		System.out.println(haha.size());
		haha.subList(2, haha.size()).clear();
		System.out.println(haha.size());
		Document html ;
		try {
			html = Jsoup.connect("https://en.wikipedia.org/wiki/Social_issues_in_India").get();
			Element para = html.body();
			String nm = para.text();
			System.out.println(nm);
			System.out.println("hello");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		

	*/
		
		String keyword = "index";
		int discovercount = 0;
		String url = "https://en.wikipedia.org/wiki/Hugh_of_Saint-Cher";
		
    	Document html ;
		try {
			html = Jsoup.connect(url).get();
			String para = html.text().toLowerCase();
			//System.out.println(para);
			int id = para.indexOf("https://en.wikipedia.org");
			//System.out.println(para.indexOf("\"", id));
			int end = para.indexOf("\"", id);
			String[] x = para.split("\"https://en.wikipedia.org");
			String[] y = x[1].split("\"");
			para = x[0] + y[1];
			//para = para.concat(y[1]);
			System.out.println("para" + para);
			for (String string: x)
				System.out.println(string);
			System.out.println("y[]:::: " + y[1]);
			if (para.contains(keyword.toLowerCase()))
			{
				System.out.println("in true mode");
				discovercount++;
				//return true;
				}
			else
			{
				System.out.println("in false mode");
				//return false;
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//return false; // default return settings.
    
	}

}
