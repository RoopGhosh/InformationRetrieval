Readme.md

This program is written in Java.

1. Download the zip file attached.
2. Open the only project in the file and consequently open the java class called Main.java
3. Run the file. 
4. The program prompts for the seed link. Please insert a formed URL following https protocol.
5. Enter the keyword if required.
6. For the ouput or list of urls obtained refer to the LoU.txt present at the same level.

Note:
1. Reference to external library JSoup.jar for parsing HTML.
2. Code was not written without any discussion with others. 
3. List 1 and List 2 part of the same zip file. For List-2 26471 URLs were crawled to 538 URLs found
