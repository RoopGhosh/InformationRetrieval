To run this file. Please Run HW4.java inside the source folder.Follow the prompt to input the files as asked.
